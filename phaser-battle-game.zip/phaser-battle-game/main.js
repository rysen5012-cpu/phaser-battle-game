// main.js - simple Phaser entry that starts a demo battle with Nayuta
const WIDTH = 900, HEIGHT = 600;

class Boot extends Phaser.Scene {
  constructor(){ super('Boot'); }
  preload(){
    this.load.json('skills','assets/skills.json');
    this.load.image('bg_tokyo','assets/bg_tokyo.png');
    this.load.image('bg_fantasy','assets/bg_fantasy.png');
    this.load.image('nayuta','assets/nayuta.png');
    this.load.image('enemy_demon','assets/enemy_demon.png');
    this.load.image('effects_blue','assets/effects_blue.png');
    // small placeholder sfx (optional)
  }
  create(){
    this.scene.start('World');
  }
}

class World extends Phaser.Scene {
  constructor(){ super('World'); }
  create(){
    this.add.image(WIDTH/2, HEIGHT/2, 'bg_tokyo').setDisplaySize(WIDTH, HEIGHT);
    this.add.text(20,20,'Nayuta — Eclipsed Soul (Demo). Press B or click to battle', {fontSize:'18px', fill:'#cfe9ff'});
    const btn = this.add.text(20,60,'Start Demo Battle', {backgroundColor:'#062034', padding:8, fill:'#cfe9ff'}).setInteractive();
    btn.on('pointerdown', ()=> this.startBattle());
    this.input.keyboard.on('keydown-B', ()=> this.startBattle());
  }

  startBattle(){
    // instantiate BattleManager from battlePlugin.js
    const bm = new BattleManager(this, { enemyId: 'demon_imp' , onComplete: (res)=> { console.log('Battle result', res); }});
    bm.start();
  }
}

const config = {
  type: Phaser.AUTO,
  width: WIDTH,
  height: HEIGHT,
  parent: 'gameContainer',
  backgroundColor: '#071426',
  scene: [Boot, World]
};

const game = new Phaser.Game(config);
