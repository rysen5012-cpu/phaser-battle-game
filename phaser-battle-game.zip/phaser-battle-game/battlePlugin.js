// battlePlugin.js - compact BattleManager (JSON-driven skills)
// Creates a simple turn-based battle UI when instantiated as new BattleManager(scene, opts).start();

class BattleManager {
  constructor(scene, opts = {}) {
    this.scene = scene;
    this.opts = opts;
    this.data = scene.cache.json.get('skills') || {};
    this.container = null;
    this.player = null;
    this.enemy = null;
    this.isPlayerTurn = true;
    this.lock = false;
    this.log = [];
  }

  start() {
    this.buildState();
    this.createUI();
    this.logAdd('Battle started: Nayuta vs Echo');
    this.startPlayerTurn();
    return this;
  }

  buildState() {
    const d = this.data;
    this.player = {
      id: 'nayuta',
      name: 'Nayuta',
      hpMax: 140,
      hp: 140,
      atk: 18,
      def: 8,
      resonance: 0,
      resonanceMax: 10,
      sprite: 'nayuta',
      skills: ['blue_slash','spirit_strike']
    };
    // choose enemy template
    const enemyId = this.opts.enemyId || 'demon_imp';
    const enemyTemplate = (d.enemies || []).find(e => e.id === enemyId) || { id:'echo', name:'Echo', hpMax:80, atk:12, def:4, sprite:'enemy_demon'};
    this.enemy = Object.assign({}, enemyTemplate);
    this.enemy.hp = this.enemy.hpMax;
  }

  createUI() {
    const s = this.scene;
    const W = s.scale.width, H = s.scale.height;
    this.container = s.add.container(0,0);
    const panel = s.add.rectangle(W/2, H/2, W-40, H-80, 0x071226).setStrokeStyle(2, 0x0ea5ff);
    this.container.add(panel);

    this.pSprite = s.add.image(160, H/2 - 40, this.player.sprite).setScale(1.0);
    this.eSprite = s.add.image(W - 200, H/2 - 40, this.enemy.sprite).setScale(1.2);
    this.container.add([this.pSprite, this.eSprite]);

    this.playerNameText = s.add.text(40, H/2 + 120, `${this.player.name}`, {fontSize:'18px', fill:'#eaf6ff'});
    this.playerHpText = s.add.text(40, H/2 + 146, `HP: ${this.player.hp}/${this.player.hpMax}`, {fontSize:'14px', fill:'#cfe9ff'});
    this.playerResText = s.add.text(40, H/2 + 168, `Res: ${this.player.resonance}/${this.player.resonanceMax}`, {fontSize:'13px', fill:'#9fcfff'});
    this.container.add([this.playerNameText, this.playerHpText, this.playerResText]);

    this.enemyNameText = s.add.text(W-320, H/2 + 120, `${this.enemy.name}`, {fontSize:'18px', fill:'#eaf6ff'});
    this.enemyHpText = s.add.text(W-320, H/2 + 146, `HP: ${this.enemy.hp}/${this.enemy.hpMax}`, {fontSize:'14px', fill:'#cfe9ff'});
    this.container.add([this.enemyNameText, this.enemyHpText]);

    // skill buttons
    this.skillButtons = [];
    const skillsMeta = this.data.skills || {};
    const startX = 240, startY = H/2 + 120, gapX = 160;
    this.player.skills.forEach((sid, i) => {
      const meta = skillsMeta[sid] || { id:sid, name:sid, resCost:0 };
      const btn = s.add.text(startX + i*gapX, startY, `${meta.name}\n(${meta.resCost})`, { fontSize:'14px', padding:8, backgroundColor:'#062034', fill:'#cfe9ff' }).setInteractive();
      btn.on('pointerdown', ()=> this.useSkill(meta.id));
      this.container.add(btn);
      this.skillButtons.push({meta, btn});
    });

    this.attackBtn = s.add.text(40, startY, 'Attack', {fontSize:'16px', padding:8, backgroundColor:'#041221', fill:'#cfe9ff'}).setInteractive();
    this.attackBtn.on('pointerdown', ()=> this.attack());

    this.defendBtn = s.add.text(120, startY, 'Defend', {fontSize:'16px', padding:8, backgroundColor:'#041221', fill:'#cfe9ff'}).setInteractive();
    this.defendBtn.on('pointerdown', ()=> this.defend());

    this.turnText = s.add.text(W/2 - 60, 24, '', {fontSize:'20px', fill:'#fff'});
    this.logText = s.add.text(40, H - 120, '', {fontSize:'14px', fill:'#9fcfff', wordWrap:{width:W-120}});
    this.updateUI();
  }

  updateUI(){
    this.playerHpText.setText(`HP: ${Math.max(0,this.player.hp)}/${this.player.hpMax}`);
    this.playerResText.setText(`Res: ${this.player.resonance}/${this.player.resonanceMax}`);
    this.enemyHpText.setText(`HP: ${Math.max(0,this.enemy.hp)}/${this.enemy.hpMax}`);
    this.turnText.setText(this.isPlayerTurn ? 'Your Turn' : 'Enemy Turn');
    // skill button states
    this.skillButtons.forEach(s => {
      const enough = this.player.resonance >= (s.meta.resCost||0);
      s.btn.setAlpha(enough ? 1.0 : 0.45);
      s.btn.setInteractive(enough || (s.meta.resCost||0)===0);
    });
  }

  logAdd(text){ this.log.unshift(text); if(this.log.length>8) this.log.length=8; this.logText.setText(this.log.join('\n')); }

  startPlayerTurn(){
    this.isPlayerTurn = true;
    this.lock = false;
    this.turnText.setText('Your Turn');
    this.updateUI();
    this.logAdd('Your move.');
  }

  endPlayerTurn(){
    this.isPlayerTurn = false;
    this.lock = true;
    this.turnText.setText('Enemy Turn');
    this.scene.time.delayedCall(700, ()=> this.enemyAct());
  }

  attack(){
    if(this.lock) return;
    const dmg = Math.max(1, Math.floor(this.player.atk - (this.enemy.def/2)));
    this.enemy.hp -= dmg;
    this.player.resonance = Math.min(this.player.resonanceMax, this.player.resonance + 2);
    this.showDamage(this.enemy, dmg);
    this.logAdd(`Nayuta attacked for ${dmg} dmg.`);
    this.updateUI();
    if(this.enemy.hp<=0) return this.win();
    this.endPlayerTurn();
  }

  defend(){
    if(this.lock) return;
    this.player.defBuff = (this.player.defBuff||0) + 6;
    this.player.buffTurns = (this.player.buffTurns||0) + 1;
    this.player.resonance = Math.min(this.player.resonanceMax, this.player.resonance + 1);
    this.logAdd('Nayuta braces and gains Res +1.');
    this.updateUI();
    this.endPlayerTurn();
  }

  useSkill(skillId){
    if(this.lock) return;
    const meta = (this.data.skills||{})[skillId];
    if(!meta){ this.logAdd('Skill missing'); return; }
    if(this.player.resonance < meta.resCost){ this.logAdd('Not enough resonance'); return; }
    this.player.resonance -= meta.resCost;
    let dmg = meta.power + Math.floor(this.player.atk * 0.4);
    if(meta.type==='resonant') {
      const eff = dmg + Math.floor(this.player.resonance * 1.2);
      const final = Math.max(1, eff - Math.floor(this.enemy.def*0.25));
      this.enemy.hp -= final;
      this.showDamage(this.enemy, final);
      this.logAdd(`Used ${meta.name} for ${final} dmg.`);
    } else {
      const final = Math.max(1, dmg - Math.floor(this.enemy.def*0.25));
      this.enemy.hp -= final;
      this.showDamage(this.enemy, final);
      this.logAdd(`Used ${meta.name} for ${final} dmg.`);
    }
    this.updateUI();
    if(this.enemy.hp<=0) return this.win();
    this.endPlayerTurn();
  }

  enemyAct(){
    if(this.enemy.hp<=0) return;
    const r = Math.random();
    let choice = 'normal';
    if(r<0.15) choice='heavy';
    if(choice==='heavy'){
      const dmg = Math.max(1, Math.floor(this.enemy.atk*1.5 - ((this.player.def||0)/2)));
      this.player.hp -= dmg;
      this.showDamage(this.player, dmg);
      this.logAdd(`${this.enemy.name} hits hard for ${dmg} dmg.`);
    } else {
      const dmg = Math.max(1, Math.floor(this.enemy.atk - ((this.player.def||0)/2)));
      this.player.hp -= dmg;
      this.showDamage(this.player, dmg);
      this.logAdd(`${this.enemy.name} attacks for ${dmg} dmg.`);
    }
    this.player.resonance = Math.min(this.player.resonanceMax, this.player.resonance + 1);
    this.updateUI();
    if(this.player.hp<=0) return this.lose();
    this.scene.time.delayedCall(800, ()=> this.startPlayerTurn());
  }

  win(){
    this.logAdd(`Victory! ${this.enemy.name} defeated.`);
    this.scene.time.delayedCall(800, ()=> { this.destroy(); if(this.opts.onComplete) this.opts.onComplete({result:'win'}); });
  }

  lose(){
    this.logAdd('Defeat... Nayuta falls.');
    this.scene.time.delayedCall(1000, ()=> { this.destroy(); if(this.opts.onComplete) this.opts.onComplete({result:'lose'}); });
  }

  showDamage(target, amount){
    const s = this.scene;
    const x = (target === this.enemy) ? this.eSprite.x : this.pSprite.x;
    const y = (target === this.enemy) ? this.eSprite.y - 80 : this.pSprite.y - 80;
    const txt = s.add.text(x, y, `-${amount}`, {fontSize:'26px', fill:'#ffd166'}).setOrigin(0.5);
    this.container.add(txt);
    s.tweens.add({ targets: txt, y: y-60, alpha:0, duration:700, onComplete: ()=> txt.destroy() });
  }

  updateUI(){ /* handled in createUI */ }

  destroy(){
    if(this.container) { this.container.destroy(true); this.container = null; }
  }
}

// Export to window for easy use
window.BattleManager = BattleManager;
